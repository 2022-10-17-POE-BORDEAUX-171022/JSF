import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;

@ManagedBean
public class StudentData {
	
	public List<Student> students;
	
	public StudentData() {
		loadSampleData();
	}
	
	public void loadSampleData() {
		
		students = new ArrayList<>();
		students.add(new Student("Samih", "Habbani", "mail1@gmail.com"));
		students.add(new Student("Patrice", "Quarteron", "mail2@gmail.com"));
		students.add(new Student("Mohamed", "Jarraya", "mail3@gmail.com"));
		
	}
	
	public List<Student> getStudents() {
		return students;
	}

}
