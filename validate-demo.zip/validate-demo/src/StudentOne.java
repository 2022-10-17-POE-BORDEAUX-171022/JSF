import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;

@ManagedBean
public class StudentOne {
	
	private String firstName;
	private String lastName;
	private String email;
	private int age;
	private String postalCode;
	private String phoneNumber;
	private String course;
	
	
	public StudentOne() {
		
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	// Méthode de controle
	// FacesContext" pour représenter les informations contextuelles associées au traitement d'une requête et à la production de la réponse correspondante.
	// Cette classe permet d'interagir avec l'interface utilisateur et le reste de l'environnement JSF
	// UIComponent component : the field
	// Object Value : the value of the field
	public void validateCourse(FacesContext context,
			UIComponent component,
			Object value) {
		
		// return rien si ma valeur est nulle
		if(value == null) {
			return;
		}
		
		// récupérer la valeur en string
		String data = value.toString();
		
		// si mon cours ne commence pas par ACADEMIE_WS
		if(!data.startsWith("ACADEMIE_WS")) {
			FacesMessage msg = new FacesMessage("Le nom de votre cours doit être précédé par la mention ACADEMIE_WS");
			// renvoyer un msg via ValidatorException
			throw new ValidatorException(msg);
		}
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

}
