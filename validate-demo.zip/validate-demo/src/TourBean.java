import javax.faces.bean.ManagedBean;

@ManagedBean
public class TourBean {
	
	private String typeOfTour;
	
	
	public TourBean() {
		
	}


	public String getTypeOfTour() {
		return typeOfTour;
	}


	public void setTypeOfTour(String typeOfTour) {
		this.typeOfTour = typeOfTour;
	}
	
	public String startTour() {
		
		if(typeOfTour != null && typeOfTour.equals("city")) {
			return "city_tour";
		} else {
			return "country_tour";
		}
		
	}

}
